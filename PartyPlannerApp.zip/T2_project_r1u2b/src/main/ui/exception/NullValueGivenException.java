package ui.exception;

//Represents an exception that is thrown when a null value is given in one of the add methods of a party item
public class NullValueGivenException extends Exception{

}
