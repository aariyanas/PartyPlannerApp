package ui;

import java.io.IOException;

//Runs the Party Planner App
public class Main {
    public static void main(String[] args) throws IOException {

        //launches a new instance of the party planner app
        new GUI();
        //new PartyPlannerApp();
    }
}